export const API_KEY="4dc91e6e-41752052-2f231715-3bf5e3d7"
export const API_URL="https://fortniteapi.io/v2/shop?lang=en"