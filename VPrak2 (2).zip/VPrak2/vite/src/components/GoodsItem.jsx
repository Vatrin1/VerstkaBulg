export function GoodsItem({
      mainId,
      displayName,
      displayDescription,
      price,
      displayAssets,
      addToBasket,
    }){

    const backgroundImage = displayAssets.length
      ? displayAssets[0].full_background
      : displayName;

    return (
      <div className="card" id={mainId}>
        <div className="card-image">
          <img src={backgroundImage} alt={displayName} />
        </div>
        <div className="card-content">
          <span className="card-title">{displayName}</span>
          <p>{displayDescription}</p>
        </div>
        <div className="card-action">
          <button
            className="btn nav-wrapper blue lighten-2"
            onClick={() => addToBasket({ mainId, displayName, price })}
          >
            Купить
          </button>
          <div>
            <span className="right">{price.finalPrice} V</span>
          </div>
        </div>
      </div>
    );
  }