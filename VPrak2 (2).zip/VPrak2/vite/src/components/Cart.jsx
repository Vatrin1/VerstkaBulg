export function Cart(props) {
    const { quantity = 0, handleBaskeShow = Function.prototype } = props;
    return (
      <div className="cart blue white-text lighten-2" onClick={handleBaskeShow}>
        <i className="material-icons">shopping_basket</i>
        {quanity ? <span className="card-quanity">{quantity}</span> : null}
      </div>
    );
  }